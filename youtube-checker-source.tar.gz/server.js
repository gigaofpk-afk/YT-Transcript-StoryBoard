const express = require('express');
const path = require('path');
const fs = require('fs');
const https = require('https');
const zlib = require('zlib');
const multer = require('multer');
const Tesseract = require('tesseract.js');

const app = express();
const PORT = process.env.PORT || 3000;

// Ensure uploads dir exists
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

// ── Screenshot cache (keeps uploaded file briefly for ZIP inclusion) ──────────
// Map<videoId, { filePath, ext, savedAt }>
const screenshotCache = new Map();
const SCREENSHOT_TTL_MS = 30 * 60 * 1000; // 30 minutes

function cacheScreenshot(videoId, filePath, ext) {
  // If a previous entry exists for this videoId, delete the old file first
  const existing = screenshotCache.get(videoId);
  if (existing && existing.filePath !== filePath) {
    try { fs.unlinkSync(existing.filePath); } catch {}
  }
  screenshotCache.set(videoId, { filePath, ext, savedAt: Date.now() });
}

function consumeScreenshot(videoId) {
  const entry = screenshotCache.get(videoId);
  if (!entry) return null;
  // Check TTL
  if (Date.now() - entry.savedAt > SCREENSHOT_TTL_MS) {
    try { fs.unlinkSync(entry.filePath); } catch {}
    screenshotCache.delete(videoId);
    return null;
  }
  // Read and delete
  try {
    const buf = fs.readFileSync(entry.filePath);
    fs.unlinkSync(entry.filePath);
    screenshotCache.delete(videoId);
    return { buf, ext: entry.ext };
  } catch {
    screenshotCache.delete(videoId);
    return null;
  }
}

// Periodic TTL cleanup every 10 minutes
setInterval(() => {
  const now = Date.now();
  for (const [videoId, entry] of screenshotCache.entries()) {
    if (now - entry.savedAt > SCREENSHOT_TTL_MS) {
      try { fs.unlinkSync(entry.filePath); } catch {}
      screenshotCache.delete(videoId);
    }
  }
}, 10 * 60 * 1000).unref();

// ── History / Cache ───────────────────────────────────────────────────────────
const historyFile = path.join(__dirname, 'history.json');
function getHistory() {
  if (fs.existsSync(historyFile)) {
    try { return JSON.parse(fs.readFileSync(historyFile, 'utf8')); } catch(e) { return {}; }
  }
  return {};
}
function saveHistory(history) {
  fs.writeFileSync(historyFile, JSON.stringify(history, null, 2));
}

// ── Multer config ─────────────────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: uploadsDir,
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  }
});
const fileFilter = (req, file, cb) => {
  cb(null, ['image/png','image/jpeg','image/jpg','image/webp'].includes(file.mimetype));
};
const upload = multer({ storage, fileFilter, limits: { fileSize: 20 * 1024 * 1024 } });

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── URL helpers ───────────────────────────────────────────────────────────────
function extractVideoId(url) {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
  ];
  for (const p of patterns) { const m = url.match(p); if (m) return m[1]; }
  return null;
}

function isValidYouTubeUrl(url) {
  try {
    const u = new URL(url);
    return ['www.youtube.com','youtube.com','youtu.be','m.youtube.com'].includes(u.hostname);
  } catch { return false; }
}

function extractPlaylistId(url) {
  try {
    const u = new URL(url);
    return u.searchParams.get('list');
  } catch { return null; }
}

function extractYouTubeFromText(text) {
  const urlPatterns = [
    /https?:\/\/(?:www\.)?youtube\.com\/watch\?[^\s"'<>]*v=([a-zA-Z0-9_-]{11})[^\s"'<>]*/,
    /https?:\/\/youtu\.be\/([a-zA-Z0-9_-]{11})[^\s"'<>]*/,
    /https?:\/\/(?:www\.)?youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})[^\s"'<>]*/,
    /https?:\/\/(?:www\.)?youtube\.com\/embed\/([a-zA-Z0-9_-]{11})[^\s"'<>]*/,
  ];
  for (const pat of urlPatterns) {
    const m = text.match(pat);
    if (m) return { url: m[0], videoId: m[1] };
  }
  const partialPatterns = [
    /(?:youtube\.com\/watch\?[^\s"'<>]*v=)([a-zA-Z0-9_-]{11})/,
    /(?:youtu\.be\/)([a-zA-Z0-9_-]{11})/,
    /(?:youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
    /[?&]v=([a-zA-Z0-9_-]{11})/,
  ];
  for (const pat of partialPatterns) {
    const m = text.match(pat);
    if (m) return { url: `https://www.youtube.com/watch?v=${m[1]}`, videoId: m[1] };
  }
  return null;
}

// ── Video info (oEmbed + youtube-search-api fallback) ─────────────────────────
async function fetchVideoInfo(videoId) {
  try {
    const fetch = require('node-fetch');
    // Primary: oEmbed (always works, no quota)
    const res = await fetch(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`);
    if (res.ok) {
      const data = await res.json();
      return {
        title: data.title,
        author: data.author_name,
        authorIcon: data.thumbnail_url || '',
        duration: '',
        thumbnail: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
      };
    }
  } catch {}

  // Fallback: youtube-search-api
  try {
    const YTSearch = require('youtube-search-api');
    const results = await YTSearch.GetListByKeyword(videoId, false, 1);
    const item = results?.items?.[0];
    if (item) {
      return {
        title: item.title,
        author: item.channelTitle || '',
        authorIcon: '',
        duration: item.length?.simpleText || '',
        thumbnail: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
      };
    }
  } catch {}

  return null;
}

// ── Transcript check ──────────────────────────────────────────────────────────
async function runTranscriptCheck(videoId) {
  const history = getHistory();
  if (history[videoId]) return history[videoId];

  const videoInfo = await fetchVideoInfo(videoId);
  if (!videoInfo) {
    return { valid: true, videoId, videoFound: false, error: 'Video not found or private/unavailable.', transcriptAvailable: false, languages: [] };
  }

  let transcriptAvailable = false;
  let languages = [];
  let transcriptError = null;

  try {
    const { YoutubeTranscript } = require('youtube-transcript');
    const transcripts = await YoutubeTranscript.fetchTranscript(videoId);
    if (transcripts && transcripts.length > 0) {
      transcriptAvailable = true;
      const langCodes = [
        { code: 'en', name: 'English' }, { code: 'es', name: 'Spanish' }, { code: 'fr', name: 'French' },
        { code: 'de', name: 'German' }, { code: 'pt', name: 'Portuguese' }, { code: 'ja', name: 'Japanese' },
        { code: 'zh-Hans', name: 'Chinese (Simplified)' }, { code: 'ar', name: 'Arabic' },
        { code: 'hi', name: 'Hindi' }, { code: 'ru', name: 'Russian' }, { code: 'ko', name: 'Korean' },
        { code: 'it', name: 'Italian' }, { code: 'tr', name: 'Turkish' }, { code: 'ur', name: 'Urdu' },
      ];
      const availableLangs = [];
      const checks = langCodes.map(async (lang) => {
        try {
          const t = await YoutubeTranscript.fetchTranscript(videoId, { lang: lang.code });
          if (t && t.length > 0) availableLangs.push(lang);
        } catch {}
      });
      await Promise.all(checks);
      languages = availableLangs.length > 0 ? availableLangs : [{ code: 'auto', name: 'Auto-detected' }];
    }
  } catch (err) {
    transcriptAvailable = false;
    if (err.message?.includes('disabled')) transcriptError = 'Transcripts are disabled for this video.';
    else if (err.message?.includes('not found')) transcriptError = 'Video not found.';
    else transcriptError = 'No transcripts/captions available for this video.';
  }

  const result = {
    valid: true, videoId, videoFound: true,
    title: videoInfo.title, author: videoInfo.author,
    thumbnail: videoInfo.thumbnail, authorIcon: videoInfo.authorIcon,
    duration: videoInfo.duration, transcriptAvailable, languages,
    transcriptError: transcriptError || null
  };
  history[videoId] = result;
  saveHistory(history);
  return result;
}

// ── Translation (Google Translate API via '@vitalets/google-translate-api') ────
async function translateText(entries, targetLang) {
  if (!targetLang || targetLang === 'original') return entries;
  try {
    const { translate } = require('@vitalets/google-translate-api');
    
    const BATCH_SIZE = 25;
    const SEPARATOR = ' ||| ';
    const translated = [];

    for (let i = 0; i < entries.length; i += BATCH_SIZE) {
      const batch = entries.slice(i, i + BATCH_SIZE);
      const combined = batch.map(e => e.text.replace(/\|\|\|/g, '...')).join(SEPARATOR);
      
      try {
        const res = await translate(combined, { to: targetLang });
        const translatedText = res.text;
        const parts = translatedText.split(SEPARATOR);
        
        for (let j = 0; j < batch.length; j++) {
          translated.push({ 
            ...batch[j], 
            text: (parts[j] || batch[j].text).trim() 
          });
        }
        
        if (i + BATCH_SIZE < entries.length) {
          await new Promise(r => setTimeout(r, 150));
        }
      } catch (batchErr) {
        console.error('Batch translation failed:', batchErr.message);
        batch.forEach(e => translated.push(e));
      }
    }
    return translated;
  } catch (err) {
    console.error('Translation setup error:', err.message);
    return entries;
  }
}

// ── SRT timestamp helper ──────────────────────────────────────────────────────
function msToSrtTime(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const milliseconds = Math.round(ms % 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return `${String(hours).padStart(2,'0')}:${String(minutes).padStart(2,'0')}:${String(seconds).padStart(2,'0')},${String(milliseconds).padStart(3,'0')}`;
}

// ── Build content helpers ─────────────────────────────────────────────────────
function buildTxt(entries) {
  return entries.map(e => e.text).join('\n');
}

function buildMd(title, author, videoUrl, langLabel, entries) {
  const lines = [
    `# ${title}`,
    ``,
    `**Channel:** ${author}`,
    `**URL:** ${videoUrl}`,
    `**Language:** ${langLabel}`,
    `**Generated:** ${new Date().toUTCString()}`,
    ``,
    `---`,
    ``,
    `## Transcript`,
    ``,
    ...entries.map(e => e.text.trim()),
  ];
  return lines.join('\n');
}

function buildSrt(entries) {
  let srt = '';
  entries.forEach((entry, index) => {
    const start = entry.offset != null ? entry.offset : (entry.start != null ? entry.start * 1000 : index * 4000);
    const dur = entry.duration != null ? entry.duration : 4000;
    srt += `${index + 1}\n${msToSrtTime(start)} --> ${msToSrtTime(start + dur)}\n${entry.text.trim()}\n\n`;
  });
  return srt;
}

async function buildDocx(title, author, videoUrl, langLabel, entries) {
  const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } = require('docx');
  const doc = new Document({
    creator: author,
    title: title,
    description: `Transcript: ${title}`,
    sections: [{
      children: [
        new Paragraph({ text: title, heading: HeadingLevel.HEADING_1 }),
        new Paragraph({ children: [new TextRun({ text: `Channel: ${author}`, bold: true })] }),
        new Paragraph({ children: [new TextRun({ text: `URL: ${videoUrl}`, color: '0563C1' })] }),
        new Paragraph({ children: [new TextRun({ text: `Language: ${langLabel}`, italics: true })] }),
        new Paragraph({ text: '' }),
        new Paragraph({ children: [new TextRun({ text: '─'.repeat(60), color: 'AAAAAA' })] }),
        new Paragraph({ text: '' }),
        ...entries.map(e => new Paragraph({ children: [new TextRun(e.text)] }))
      ]
    }]
  });
  return Packer.toBuffer(doc);
}

async function buildPdf(title, author, videoUrl, langLabel, entries) {
  const PDFDocument = require('pdfkit');
  return new Promise((resolve, reject) => {
    const pdf = new PDFDocument({ margin: 55, size: 'A4' });
    const chunks = [];
    pdf.on('data', c => chunks.push(c));
    pdf.on('end', () => resolve(Buffer.concat(chunks)));
    pdf.on('error', reject);

    // Header
    pdf.fontSize(18).font('Helvetica-Bold').text(title, { align: 'left' });
    pdf.moveDown(0.4);
    pdf.fontSize(10).font('Helvetica')
      .fillColor('#555555').text(`Channel: ${author}`)
      .text(`URL: ${videoUrl}`)
      .text(`Language: ${langLabel}`)
      .text(`Generated: ${new Date().toUTCString()}`);
    pdf.moveDown(0.5);
    pdf.moveTo(55, pdf.y).lineTo(540, pdf.y).strokeColor('#CCCCCC').stroke();
    pdf.moveDown(0.7);

    // Transcript lines
    pdf.fillColor('#222222').fontSize(10).font('Helvetica');
    entries.forEach(entry => {
      if (pdf.y > 760) pdf.addPage();
      pdf.text(entry.text, { align: 'left', lineGap: 2 });
    });

    pdf.end();
  });
}

// ── Gemini STT Transcription Helpers ──────────────────────────────────────────
const { exec } = require('child_process');

async function ensureYtdlp() {
  const localExe = path.join(__dirname, 'yt-dlp.exe');
  if (fs.existsSync(localExe)) {
    return localExe;
  }
  
  return new Promise((resolve) => {
    exec('yt-dlp --version', async (error) => {
      if (!error) {
        resolve('yt-dlp');
      } else {
        console.log('Downloading yt-dlp.exe...');
        try {
          const fetch = require('node-fetch');
          const res = await fetch('https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe');
          if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
          const buffer = await res.buffer();
          fs.writeFileSync(localExe, buffer);
          console.log('yt-dlp.exe downloaded successfully.');
          resolve(localExe);
        } catch (downloadErr) {
          console.error('Failed to download yt-dlp.exe:', downloadErr.message);
          resolve(null);
        }
      }
    });
  });
}

async function downloadYoutubeAudio(videoId) {
  const ytdlpPath = await ensureYtdlp();
  if (!ytdlpPath) throw new Error('yt-dlp is not available and could not be downloaded.');

  const outputPath = path.join(__dirname, 'uploads', `audio_${videoId}.m4a`);
  
  if (!fs.existsSync(path.join(__dirname, 'uploads'))) {
    fs.mkdirSync(path.join(__dirname, 'uploads'), { recursive: true });
  }

  if (fs.existsSync(outputPath)) {
    try { fs.unlinkSync(outputPath); } catch {}
  }

  return new Promise((resolve, reject) => {
    const cmd = `"${ytdlpPath}" -f 140 -o "${outputPath}" "https://www.youtube.com/watch?v=${videoId}"`;
    exec(cmd, (error, stdout, stderr) => {
      if (error) {
        reject(new Error(`yt-dlp failed: ${stderr || error.message}`));
      } else {
        resolve(outputPath);
      }
    });
  });
}

async function uploadAudioToGemini(filePath, mimeType, apiKey) {
  const stats = fs.statSync(filePath);
  const fileSize = stats.size;

  const initUrl = `https://generativelanguage.googleapis.com/upload/v1beta/files?key=${apiKey}`;
  const fetch = require('node-fetch');
  const initRes = await fetch(initUrl, {
    method: 'POST',
    headers: {
      'X-Goog-Upload-Protocol': 'resumable',
      'X-Goog-Upload-Command': 'start',
      'X-Goog-Upload-Header-Content-Length': fileSize.toString(),
      'X-Goog-Upload-Header-Content-Type': mimeType,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      file: { display_name: path.basename(filePath) }
    })
  });

  if (!initRes.ok) {
    throw new Error(`Failed to initialize Gemini file upload: ${initRes.status} ${await initRes.text()}`);
  }

  const uploadUrl = initRes.headers.get('x-goog-upload-url');
  if (!uploadUrl) {
    throw new Error('Upload URL not received from Gemini.');
  }

  const fileStream = fs.createReadStream(filePath);
  const uploadRes = await fetch(uploadUrl, {
    method: 'POST',
    headers: {
      'Content-Length': fileSize.toString(),
      'X-Goog-Upload-Offset': '0',
      'X-Goog-Upload-Command': 'upload, finalize'
    },
    body: fileStream
  });

  if (!uploadRes.ok) {
    throw new Error(`Gemini byte upload failed: ${uploadRes.status} ${await uploadRes.text()}`);
  }

  const uploadInfo = await uploadRes.json();
  return uploadInfo.file.uri;
}

async function transcribeAudioWithGemini(fileUri, mimeType, apiKey) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
  const fetch = require('node-fetch');
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [
        {
          role: 'user',
          parts: [
            { text: 'Transcribe this audio file. Output the transcription as a chronological list of segments with timestamps in [MM:SS] format if possible, followed by the text. E.g. [00:12] Welcome back to our channel.' },
            { file_data: { file_uri: fileUri, mime_type: mimeType } }
          ]
        }
      ]
    })
  });

  if (!response.ok) {
    throw new Error(`Gemini transcription model failed: ${response.status} ${await response.text()}`);
  }

  const data = await response.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) {
    throw new Error('Gemini returned an empty transcription response.');
  }
  return text;
}

async function deleteFileFromGemini(fileUri, apiKey) {
  try {
    const fileId = fileUri.split('/').pop();
    const url = `https://generativelanguage.googleapis.com/v1beta/files/${fileId}?key=${apiKey}`;
    const fetch = require('node-fetch');
    await fetch(url, { method: 'DELETE' });
  } catch (err) {
    console.error('Failed to clean up Gemini file:', err.message);
  }
}

function parseGeminiTranscriptToEntries(rawText) {
  const lines = rawText.split('\n');
  const entries = [];
  const timeRegex = /(?:\[)?(\d{1,2}):(\d{2})(?::(\d{2}))?(?:\])?/;

  let lastTimeMs = 0;
  
  lines.forEach((line) => {
    const trimmed = line.trim();
    if (!trimmed) return;
    
    const match = trimmed.match(timeRegex);
    let text = trimmed;
    let startMs = lastTimeMs;
    
    if (match) {
      const min = parseInt(match[1], 10);
      const sec = parseInt(match[2], 10);
      const hour = match[3] ? parseInt(match[3], 10) : 0;
      
      startMs = ((hour * 3600) + (min * 60) + sec) * 1000;
      lastTimeMs = startMs;
      
      text = trimmed.replace(match[0], '').trim();
      text = text.replace(/^[:\-\s\u2013\u2014]+/, '').trim();
    }
    
    if (text) {
      entries.push({
        text,
        start: startMs / 1000,
        duration: 4000,
        offset: startMs
      });
    }
  });

  for (let i = 0; i < entries.length - 1; i++) {
    entries[i].duration = (entries[i+1].start - entries[i].start) * 1000;
  }
  
  return entries;
}

// ── Fetch transcript entries ──────────────────────────────────────────────────
async function fetchTranscriptEntries(videoId, lang) {
  if (lang === 'gemini') {
    const history = getHistory();
    if (history[videoId] && history[videoId].geminiTranscript) {
      return history[videoId].geminiTranscript;
    }
  }
  const { YoutubeTranscript } = require('youtube-transcript');
  try {
    return await YoutubeTranscript.fetchTranscript(videoId, lang && lang !== 'auto' ? { lang } : {});
  } catch {
    return await YoutubeTranscript.fetchTranscript(videoId);
  }
}

// ── Storyboard Spec Scraper & Helpers ─────────────────────────────────────────
async function fetchStoryboardSpec(videoId) {
  try {
    const fetch = require('node-fetch');
    const url = `https://www.youtube.com/watch?v=${videoId}`;
    const headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept-Language': 'en-US,en;q=0.9'
    };
    const res = await fetch(url, { headers });
    const html = await res.text();
    
    const playerResponseMatch = html.match(/ytInitialPlayerResponse\s*=\s*({.+?});/);
    let playerResponse = null;
    if (playerResponseMatch) {
      try {
        playerResponse = JSON.parse(playerResponseMatch[1]);
      } catch {}
    }
    
    if (!playerResponse) {
      const rawMatch = html.match(/"playerStoryboardSpecRenderer":\s*(\{.+\})/);
      if (rawMatch) {
        try {
          playerResponse = { storyboards: JSON.parse(rawMatch[1]) };
        } catch {}
      }
    }
    
    const storyboards = playerResponse?.storyboards;
    const renderer = storyboards?.playerStoryboardSpecRenderer || storyboards?.playerLiveStoryboardSpecRenderer;
    return renderer?.spec || null;
  } catch (err) {
    console.error('Failed to fetch storyboard spec:', err.message);
    return null;
  }
}

// ════════════════════════════════════════════════════════════════════════════════
// API ROUTES
// ════════════════════════════════════════════════════════════════════════════════

// ── Fetch Storyboards Spec ────────────────────────────────────────────────────
app.get('/api/storyboards', async (req, res) => {
  const { videoId } = req.query;
  if (!videoId) return res.status(400).json({ error: 'videoId is required.' });
  
  try {
    const spec = await fetchStoryboardSpec(videoId);
    if (!spec) {
      return res.status(404).json({ error: 'Storyboard spec not found for this video.' });
    }
    
    const parts = spec.split('|');
    const baseUrlTemplate = parts[0];
    const levels = [];
    for (let i = 1; i < parts.length; i++) {
      const seg = parts[i].split('#');
      if (seg.length < 8) continue;
      
      const w = parseInt(seg[0], 10);
      const h = parseInt(seg[1], 10);
      const count = parseInt(seg[2], 10);
      const cols = parseInt(seg[3], 10);
      const rows = parseInt(seg[4], 10);
      const interval = parseInt(seg[5], 10);
      const prefix = seg[6]; 
      const token = seg[7]; 
      levels.push({ w, h, count, cols, rows, interval, prefix, token });
    }
    
    res.json({ baseUrlTemplate, levels });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Storyboard Image CORS Proxy ───────────────────────────────────────────────
app.get('/api/storyboard-proxy', async (req, res) => {
  const { url } = req.query;
  if (!url) return res.status(400).send('url is required.');
  
  try {
    const fetch = require('node-fetch');
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    });

    if (!response.ok) {
      return res.status(response.status).send(`Failed to fetch storyboard image: ${response.statusText}`);
    }

    res.setHeader('Content-Type', response.headers.get('content-type') || 'image/webp');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    response.body.pipe(res);
  } catch (err) {
    res.status(500).send(err.message);
  }
});


// ── Transcribe using Gemini API ────────────────────────────────────────────────
app.post('/api/transcribe-gemini', async (req, res) => {
  const { videoId, apiKey } = req.body;
  if (!videoId) return res.status(400).json({ error: 'videoId is required.' });
  if (!apiKey) return res.status(400).json({ error: 'Gemini API key is required.' });

  let audioPath = null;
  let fileUri = null;

  try {
    const videoInfo = await fetchVideoInfo(videoId);
    if (!videoInfo) {
      return res.status(404).json({ error: 'Video not found or unavailable.' });
    }

    audioPath = await downloadYoutubeAudio(videoId);

    const mimeType = 'audio/mp4'; 
    fileUri = await uploadAudioToGemini(audioPath, mimeType, apiKey);

    const rawText = await transcribeAudioWithGemini(fileUri, mimeType, apiKey);

    const entries = parseGeminiTranscriptToEntries(rawText);
    if (entries.length === 0) {
      throw new Error('Could not parse any transcript segments from model response.');
    }

    const history = getHistory();
    history[videoId] = {
      valid: true,
      videoId,
      videoFound: true,
      title: videoInfo.title,
      author: videoInfo.author,
      thumbnail: videoInfo.thumbnail,
      authorIcon: videoInfo.authorIcon || '',
      duration: videoInfo.duration || '',
      transcriptAvailable: true,
      languages: [{ code: 'gemini', name: 'Gemini STT (English/Auto)' }],
      geminiTranscript: entries,
      transcriptError: null
    };
    saveHistory(history);

    res.json(history[videoId]);
  } catch (err) {
    console.error('Gemini STT Error:', err);
    res.status(500).json({ error: 'Transcription failed: ' + err.message });
  } finally {
    if (audioPath && fs.existsSync(audioPath)) {
      try { fs.unlinkSync(audioPath); } catch {}
    }
    if (fileUri) {
      await deleteFileFromGemini(fileUri, apiKey);
    }
  }
});

// ── Single URL check ──────────────────────────────────────────────────────────
app.post('/api/check', async (req, res) => {
  const { url } = req.body;
  if (!url || typeof url !== 'string') return res.json({ valid: false, error: 'No URL provided.' });
  const trimmed = url.trim();
  if (!isValidYouTubeUrl(trimmed)) return res.json({ valid: false, error: 'Not a valid YouTube URL.' });
  const videoId = extractVideoId(trimmed);
  if (!videoId) return res.json({ valid: false, error: 'Could not extract video ID from URL.' });
  return res.json(await runTranscriptCheck(videoId));
});

// ── Batch URL check ───────────────────────────────────────────────────────────
app.post('/api/check-batch', async (req, res) => {
  const { urls } = req.body;
  if (!Array.isArray(urls) || urls.length === 0) return res.json({ error: 'No URLs provided.' });
  
  // Load Balancing: Process 5 at a time to prevent overloading API
  const CHUNK = 5;
  const allResults = [];

  for (let i = 0; i < urls.length; i += CHUNK) {
    const chunk = urls.slice(i, i + CHUNK);
    const chunkResults = await Promise.allSettled(
      chunk.map(async (rawUrl) => {
        const url = (rawUrl || '').trim();
        if (!url) return null;
        if (!isValidYouTubeUrl(url)) return { url, valid: false, error: 'Not a valid YouTube URL.' };
        const videoId = extractVideoId(url);
        if (!videoId) return { url, valid: false, error: 'Could not extract video ID.' };
        return { url, ...(await runTranscriptCheck(videoId)) };
      })
    );
    allResults.push(...chunkResults);
    if (i + CHUNK < urls.length) {
      await new Promise(r => setTimeout(r, 500)); // Sleep between chunks
    }
  }

  res.json(allResults.map(r => r.status === 'fulfilled' ? r.value : { valid: false, error: r.reason?.message }).filter(Boolean));
});

// ── InnerTube playlist fetcher (unlimited, paginated) ────────────────────────
function deepFind(obj, key, results = []) {
  if (!obj || typeof obj !== 'object') return results;
  if (Object.prototype.hasOwnProperty.call(obj, key)) results.push(obj[key]);
  for (const v of Object.values(obj)) {
    if (v && typeof v === 'object') deepFind(v, key, results);
  }
  return results;
}

async function innerTubeBrowse(body) {
  return new Promise((resolve, reject) => {
    const postData = Buffer.from(JSON.stringify(body));
    const req = https.request({
      hostname: 'www.youtube.com',
      path: '/youtubei/v1/browse',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': postData.length,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Origin': 'https://www.youtube.com',
        'Referer': 'https://www.youtube.com/',
        'X-Youtube-Client-Name': '1',
        'X-Youtube-Client-Version': '2.20260626.01.00',
      }
    }, r => {
      const chunks = [];
      r.on('data', d => chunks.push(d));
      r.on('end', () => {
        try {
          resolve({ status: r.statusCode, data: JSON.parse(Buffer.concat(chunks).toString()) });
        } catch (e) {
          reject(e);
        }
      });
    });
    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

const INNERTUBE_CTX = { client: { clientName: 'WEB', clientVersion: '2.20260626.01.00', hl: 'en', gl: 'US' } };

async function fetchPlaylistAllVideos(listId) {
  const allVideos = [];
  let continuationToken = null;
  let title = 'Unknown Playlist';
  let author = '';
  let thumbnail = '';
  let estimatedCount = 0;
  let page = 0;

  do {
    let body;
    if (page === 0) {
      body = { context: INNERTUBE_CTX, browseId: 'VL' + listId };
    } else {
      body = { context: INNERTUBE_CTX, continuation: continuationToken };
    }

    const { status, data } = await innerTubeBrowse(body);
    if (status !== 200) throw new Error(`InnerTube returned status ${status}`);

    // Extract header info on first page
    if (page === 0) {
      const headers = deepFind(data, 'playlistHeaderRenderer');
      if (headers[0]) {
        title = headers[0].title?.simpleText ||
                headers[0].title?.runs?.[0]?.text || title;
        const countRuns = headers[0].numVideosText?.runs;
        if (countRuns) estimatedCount = parseInt(countRuns[0]?.text?.replace(/[^0-9]/g, '')) || 0;
      }
      const metas = deepFind(data, 'playlistMetadataRenderer');
      if (metas[0] && title === 'Unknown Playlist') {
        title = metas[0].title || title;
      }
      // Channel thumbnail
      const thumbs = deepFind(data, 'thumbnailViewModel');
      if (thumbs[0]) thumbnail = thumbs[0].image?.sources?.[0]?.url || '';
    }

    // Extract videos from lockupViewModel (new format) or playlistVideoRenderer (old format)
    const str = JSON.stringify(data);
    const videoIdRe = /"videoId":"([a-zA-Z0-9_-]{11})"/g;
    const lockups = deepFind(data, 'lockupViewModel');

    if (lockups.length > 0) {
      for (const lockup of lockups) {
        const lockupStr = JSON.stringify(lockup);
        const vidMatch = lockupStr.match(/"videoId":"([a-zA-Z0-9_-]{11})"/);
        if (!vidMatch) continue;
        const videoId = vidMatch[1];
        if (allVideos.find(v => v.videoId === videoId)) continue; // dedup

        // Extract title from metadata
        const titleContent = lockup.metadata?.lockupMetadataViewModel?.title?.content ||
                             lockup.metadata?.lockupMetadataViewModel?.title?.runs?.[0]?.text || '';
        // Duration from overlay
        let duration = '';
        const durMatch = lockupStr.match(/"text":"(\d+:\d{2}(?::\d{2})?)"/);  
        if (durMatch) duration = durMatch[1];

        allVideos.push({
          videoId,
          title: titleContent || `Video ${videoId}`,
          duration,
          url: `https://www.youtube.com/watch?v=${videoId}`
        });
      }
    } else {
      // Fallback: playlistVideoRenderer (old format)
      const videoRenderers = deepFind(data, 'playlistVideoRenderer');
      for (const v of videoRenderers) {
        if (!v.videoId) continue;
        if (allVideos.find(x => x.videoId === v.videoId)) continue;
        allVideos.push({
          videoId: v.videoId,
          title: v.title?.runs?.[0]?.text || `Video ${v.videoId}`,
          duration: v.lengthText?.simpleText || '',
          url: `https://www.youtube.com/watch?v=${v.videoId}`
        });
      }
    }

    // Find continuation token
    const conts = deepFind(data, 'continuationCommand');
    const nextToken = conts.find(c => c.token);
    continuationToken = nextToken?.token || null;
    page++;

    // Safety limit: max 200 pages (20,000 videos)
    if (page > 200) break;

    // Small delay to be polite
    if (continuationToken) await new Promise(r => setTimeout(r, 150));
  } while (continuationToken);

  return { title, author, thumbnail, estimatedCount: estimatedCount || allVideos.length, videos: allVideos };
}

// ── Playlist info ─────────────────────────────────────────────────────────────
app.post('/api/playlist-info', async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: 'URL required.' });

  const listId = extractPlaylistId(url);
  if (!listId) return res.status(400).json({ error: 'No playlist ID found in URL.' });

  try {
    const playlist = await fetchPlaylistAllVideos(listId);
    res.json({
      playlistId: listId,
      title: playlist.title,
      author: playlist.author,
      thumbnail: playlist.thumbnail,
      videoCount: playlist.estimatedCount,
      videos: playlist.videos
    });
  } catch (err) {
    console.error('Playlist error:', err.message);
    res.status(500).json({ error: 'Failed to fetch playlist: ' + err.message });
  }
});

// ── History ───────────────────────────────────────────────────────────────────
app.get('/api/history', (req, res) => {
  res.json(Object.values(getHistory()));
});

// ── Download transcript (single format) ──────────────────────────────────────
app.post('/api/download-transcript', async (req, res) => {
  const { videoId, lang, format, targetLang } = req.body;
  if (!videoId) return res.status(400).json({ error: 'videoId is required.' });
  if (!['txt', 'srt', 'md'].includes(format)) return res.status(400).json({ error: 'format must be txt, srt or md.' });

  try {
    const history = getHistory();
    let cached = history[videoId];
    if (!cached) {
      cached = await runTranscriptCheck(videoId);
    }
    const title = cached.title || `Video_${videoId}`;
    const author = cached.author || '';
    const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;
    const safeTitle = title.replace(/[^a-zA-Z0-9 _\-]/g, '').replace(/\s+/g, '_').substring(0, 60);

    const effectiveTarget = targetLang || 'original';

    if (effectiveTarget === 'all') {
      const JSZip = require('jszip');
      const zip = new JSZip();
      const availableLangs = (cached.languages && cached.languages.length > 0)
        ? cached.languages
        : [{ code: 'original', name: 'Original' }];

      const fetchPromises = availableLangs.map(async (l) => {
        try {
          const langCode = l.code === 'original' ? 'auto' : l.code;
          const entries = await fetchTranscriptEntries(videoId, langCode);
          if (entries && entries.length > 0) {
            const langSuffix = l.code;
            const langLabel = l.name;
            let content = '';
            if (format === 'txt') content = buildTxt(entries);
            else if (format === 'srt') content = buildSrt(entries);
            else if (format === 'md') content = buildMd(title, author, videoUrl, langLabel, entries);
            zip.file(`${safeTitle}_${langSuffix}.${format}`, content);
          }
        } catch (err) {
          console.error(`Failed to fetch ${l.code} for video ${videoId}:`, err.message);
        }
      });
      await Promise.all(fetchPromises);

      const zipBuffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 6 } });
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="Video_${safeTitle}_All_Languages_${format.toUpperCase()}.zip"`);
      return res.send(zipBuffer);
    }

    let entries = await fetchTranscriptEntries(videoId, lang);
    if (!entries || entries.length === 0) return res.status(404).json({ error: 'No transcript found for this video.' });

    if (effectiveTarget !== 'original') entries = await translateText(entries, effectiveTarget);

    const langLabel = effectiveTarget === 'original' ? 'Original (no translation)' : effectiveTarget.toUpperCase();
    const langLabelName = effectiveTarget === 'original' ? 'Original' : effectiveTarget.toUpperCase();
    const filename = `Video_${safeTitle}_${langLabelName}.${format}`;

    if (format === 'txt') {
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      return res.send(buildTxt(entries));
    }
    if (format === 'srt') {
      res.setHeader('Content-Type', 'application/x-subrip; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      return res.send(buildSrt(entries));
    }
    if (format === 'md') {
      res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      return res.send(buildMd(title, author, videoUrl, langLabel, entries));
    }
  } catch (err) {
    console.error('Download transcript error:', err);
    return res.status(500).json({ error: 'Failed to fetch transcript: ' + err.message });
  }
});

// ── Download ZIP (txt + srt + docx + pdf + thumbnail + metadata) ─────────────
app.post('/api/download-zip', async (req, res) => {
  const { videoId, lang, targetLang, destPath } = req.body;
  if (!videoId) return res.status(400).json({ error: 'videoId is required.' });

  try {
    const JSZip = require('jszip');
    const fetch = require('node-fetch');

    const history = getHistory();
    let cached = history[videoId];
    if (!cached) {
      cached = await runTranscriptCheck(videoId);
    }
    const title = cached.title || `Video_${videoId}`;
    const author = cached.author || '';
    const authorIcon = cached.authorIcon || '';
    const thumbnailUrl = cached.thumbnail || `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
    const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;
    const safeTitle = title.replace(/[^a-zA-Z0-9 _\-]/g, '').replace(/\s+/g, '_').substring(0, 55);

    const effectiveTarget = targetLang || 'original';

    // Fetch thumbnail image
    let thumbnailBuffer = null;
    try {
      const thumbRes = await fetch(thumbnailUrl);
      if (thumbRes.ok) thumbnailBuffer = await thumbRes.buffer();
    } catch {}

    const zip = new JSZip();
    const folder = zip.folder(safeTitle);

    if (effectiveTarget === 'all') {
      const availableLangs = (cached.languages && cached.languages.length > 0)
        ? cached.languages
        : [{ code: 'original', name: 'Original' }];

      let totalCaptionsCount = 0;
      for (const l of availableLangs) {
        try {
          const langCode = l.code === 'original' ? 'auto' : l.code;
          let entries = await fetchTranscriptEntries(videoId, langCode);
          if (!entries || entries.length === 0) continue;

          totalCaptionsCount += entries.length;
          const langLabel = l.name;
          const langSuffix = l.code;

          const [txtContent, srtContent, mdContent, docxBuffer, pdfBuffer] = await Promise.all([
            Promise.resolve(buildTxt(entries)),
            Promise.resolve(buildSrt(entries)),
            Promise.resolve(buildMd(title, author, videoUrl, langLabel, entries)),
            buildDocx(title, author, videoUrl, langLabel, entries),
            buildPdf(title, author, videoUrl, langLabel, entries),
          ]);

          const langFolder = folder.folder(langLabel);
          langFolder.file(`${safeTitle}_${langSuffix}.txt`, txtContent);
          langFolder.file(`${safeTitle}_${langSuffix}.srt`, srtContent);
          langFolder.file(`${safeTitle}_${langSuffix}.md`, mdContent);
          langFolder.file(`${safeTitle}_${langSuffix}.docx`, docxBuffer);
          langFolder.file(`${safeTitle}_${langSuffix}.pdf`, pdfBuffer);
        } catch (err) {
          console.error(`Failed to build formats for ${l.code} of ${videoId}:`, err.message);
        }
      }

      const metadata = {
        videoId,
        title,
        channel: author,
        channelIcon: authorIcon,
        videoUrl,
        thumbnail: thumbnailUrl,
        transcriptLanguage: 'ALL AVAILABLE LANGUAGES',
        captionCount: totalCaptionsCount,
        generatedAt: new Date().toISOString()
      };
      folder.file('metadata.json', JSON.stringify(metadata, null, 2));
      if (thumbnailBuffer) folder.file('thumbnail.jpg', thumbnailBuffer);
      const cachedShot = consumeScreenshot(videoId);
      if (cachedShot) folder.file(`input_screenshot${cachedShot.ext}`, cachedShot.buf);

      const zipBuffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 6 } });
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="Video_${safeTitle}_All_Languages_All_Formats_Master.zip"`);
      return res.send(zipBuffer);
    }

    // Fetch transcript
    let entries = await fetchTranscriptEntries(videoId, lang);
    if (!entries || entries.length === 0) return res.status(404).json({ error: 'No transcript found for this video.' });

    if (effectiveTarget !== 'original') entries = await translateText(entries, effectiveTarget);

    const langSuffix = effectiveTarget === 'original' ? 'orig' : effectiveTarget;
    const langLabel = effectiveTarget === 'original' ? 'Original (no translation)' : effectiveTarget.toUpperCase();

    // Generate all formats in parallel
    const [txtContent, srtContent, mdContent, docxBuffer, pdfBuffer] = await Promise.all([
      Promise.resolve(buildTxt(entries)),
      Promise.resolve(buildSrt(entries)),
      Promise.resolve(buildMd(title, author, videoUrl, langLabel, entries)),
      buildDocx(title, author, videoUrl, langLabel, entries),
      buildPdf(title, author, videoUrl, langLabel, entries),
    ]);

    const metadata = {
      videoId,
      title,
      channel: author,
      channelIcon: authorIcon,
      videoUrl,
      thumbnail: thumbnailUrl,
      transcriptLanguage: langLabel,
      captionCount: entries.length,
      generatedAt: new Date().toISOString()
    };

    folder.file(`${safeTitle}_${langSuffix}.txt`,  txtContent);
    folder.file(`${safeTitle}_${langSuffix}.srt`,  srtContent);
    folder.file(`${safeTitle}_${langSuffix}.md`,   mdContent);
    folder.file(`${safeTitle}_${langSuffix}.docx`, docxBuffer);
    folder.file(`${safeTitle}_${langSuffix}.pdf`,  pdfBuffer);
    folder.file('metadata.json', JSON.stringify(metadata, null, 2));
    if (thumbnailBuffer) folder.file('thumbnail.jpg', thumbnailBuffer);
    // Include the user's uploaded screenshot if it was used to find this video
    const cachedShot = consumeScreenshot(videoId);
    if (cachedShot) folder.file(`input_screenshot${cachedShot.ext}`, cachedShot.buf);

    const zipBuffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 6 } });

    const langLabelName = effectiveTarget === 'original' ? 'Original' : effectiveTarget.toUpperCase();
    const filename = `Video_${safeTitle}_${langLabelName}_All_Formats_Master.zip`;
    
    if (destPath) {
      const fs = require('fs');
      const path = require('path');
      if (!fs.existsSync(destPath)) fs.mkdirSync(destPath, { recursive: true });
      const fullPath = path.join(destPath, filename);
      fs.writeFileSync(fullPath, zipBuffer);
      return res.json({ success: true, path: fullPath });
    }
    
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(zipBuffer);
  } catch (err) {
    console.error('ZIP download error:', err);
    res.status(500).json({ error: 'Failed to create ZIP: ' + err.message });
  }
});

// ── Download Batch Helper ────────────────────────────────────────────────────
function buildLogsText(logEntries, title, isPlaylist, targetLang) {
  const lines = [
    `==================================================`,
    ` YouTube Transcript Checker - Download Logs & Summary`,
    `==================================================`,
    `Generated on   : ${new Date().toUTCString()}`,
    `Type           : ${isPlaylist ? 'Playlist' : 'Batch Links'}`,
    `Name/Title     : ${title || 'N/A'}`,
    `Target Language: ${targetLang === 'original' ? 'Original' : (targetLang === 'all' ? 'All Available' : targetLang.toUpperCase())}`,
    ``,
    `--------------------------------------------------`,
    ` Processing Summary`,
    `--------------------------------------------------`,
  ];

  let successCount = 0;
  let failedCount = 0;

  logEntries.forEach((entry, i) => {
    if (!entry) return;
    if (entry.status === 'SUCCESS') successCount++;
    else failedCount++;

    lines.push(`[${i + 1}] Video ID : ${entry.videoId}`);
    lines.push(`    Title    : ${entry.title || 'N/A'}`);
    lines.push(`    Status   : ${entry.status}`);
    if (entry.status === 'SUCCESS') {
      lines.push(`    Languages: ${entry.sourceLang || 'N/A'}`);
      lines.push(`    Details  : ${entry.details}`);
    } else {
      lines.push(`    Reason   : ${entry.error || 'Unknown error'}`);
    }
    lines.push(``);
  });

  lines.push(`--------------------------------------------------`);
  lines.push(`Total Processed: ${logEntries.length}`);
  lines.push(`Success        : ${successCount}`);
  lines.push(`Failed         : ${failedCount}`);
  lines.push(`==================================================`);

  return lines.join('\n');
}

// ── Download Batch (ZIP of txt/srt files, or folders of all formats) ─────────
app.post('/api/download-batch', async (req, res) => {
  const { items, format, targetLang, isPlaylist, playlistTitle } = req.body;
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'items array is required and must not be empty.' });
  }
  if (!['txt', 'srt', 'md', 'zip'].includes(format)) {
    return res.status(400).json({ error: 'format must be txt, srt, md, or zip.' });
  }

  try {
    const JSZip = require('jszip');
    const fetch = require('node-fetch');
    const zip = new JSZip();

    const effectiveTarget = targetLang || 'original';
    const history = getHistory();

    const logEntries = new Array(items.length);
    const playlistMetadata = new Array(items.length);
    const allThumbnailsFolder = format === 'zip' ? zip.folder('All_Thumbnails') : null;

    const fetchPromises = items.map(async (item, idx) => {
      const { videoId, lang } = item;
      if (!videoId) return;

      try {
        let cached = history[videoId];
        if (!cached) cached = await runTranscriptCheck(videoId);

        const title = cached.title || `Video_${videoId}`;
        const author = cached.author || '';
        const authorIcon = cached.authorIcon || '';
        const thumbnailUrl = cached.thumbnail || `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
        const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;
        const safeTitle = title.replace(/[^a-zA-Z0-9 _\-]/g, '').replace(/\s+/g, '_').substring(0, 55);

        // Fetch thumbnail image
        let thumbnailBuffer = null;
        try {
          const thumbRes = await fetch(thumbnailUrl);
          if (thumbRes.ok) thumbnailBuffer = await thumbRes.buffer();
        } catch {}

        if (thumbnailBuffer && allThumbnailsFolder) {
          allThumbnailsFolder.file(`${safeTitle}.jpg`, thumbnailBuffer);
        }

        if (effectiveTarget === 'all') {
          const availableLangs = (cached.languages && cached.languages.length > 0)
            ? cached.languages
            : [{ code: 'original', name: 'Original' }];

          if (format === 'zip') {
            const subFolder = zip.folder(safeTitle);
            let totalCaptionsCount = 0;

            for (const l of availableLangs) {
              try {
                const langCode = l.code === 'original' ? 'auto' : l.code;
                let entries = await fetchTranscriptEntries(videoId, langCode);
                if (!entries || entries.length === 0) continue;

                totalCaptionsCount += entries.length;
                const langLabel = l.name;
                const langSuffix = l.code;

                const [txtContent, srtContent, mdContent, docxBuffer, pdfBuffer] = await Promise.all([
                  Promise.resolve(buildTxt(entries)),
                  Promise.resolve(buildSrt(entries)),
                  Promise.resolve(buildMd(title, author, videoUrl, langLabel, entries)),
                  buildDocx(title, author, videoUrl, langLabel, entries),
                  buildPdf(title, author, videoUrl, langLabel, entries),
                ]);

                const langFolder = subFolder.folder(langLabel);
                langFolder.file(`${safeTitle}_${langSuffix}.txt`,  txtContent);
                langFolder.file(`${safeTitle}_${langSuffix}.srt`,  srtContent);
                langFolder.file(`${safeTitle}_${langSuffix}.md`,   mdContent);
                langFolder.file(`${safeTitle}_${langSuffix}.docx`, docxBuffer);
                langFolder.file(`${safeTitle}_${langSuffix}.pdf`,  pdfBuffer);
              } catch (err) {
                console.error(`Failed to build batch format for ${l.code} of ${videoId}:`, err.message);
              }
            }

            const metadata = {
              videoId,
              title,
              channel: author,
              channelIcon: authorIcon,
              videoUrl,
              thumbnail: thumbnailUrl,
              transcriptLanguage: 'ALL AVAILABLE LANGUAGES',
              captionCount: totalCaptionsCount,
              generatedAt: new Date().toISOString()
            };
            subFolder.file('metadata.json', JSON.stringify(metadata, null, 2));

            if (thumbnailBuffer) subFolder.file('thumbnail.jpg', thumbnailBuffer);

            const batchShot = consumeScreenshot(videoId);
            if (batchShot) subFolder.file(`input_screenshot${batchShot.ext}`, batchShot.buf);

            logEntries[idx] = {
              videoId,
              title,
              status: 'SUCCESS',
              sourceLang: availableLangs.map(l => l.name).join(', '),
              details: 'All formats ZIP (all available languages)'
            };
            playlistMetadata[idx] = {
              videoId,
              title,
              channel: author,
              videoUrl,
              thumbnail: thumbnailUrl,
              status: 'SUCCESS'
            };
          } else {
            let successLangs = [];
            for (const l of availableLangs) {
              try {
                const langCode = l.code === 'original' ? 'auto' : l.code;
                const entries = await fetchTranscriptEntries(videoId, langCode);
                if (entries && entries.length > 0) {
                  successLangs.push(l.name);
                  const langSuffix = l.code;
                  const langLabel = l.name;
                  if (format === 'txt') {
                    zip.file(`${safeTitle}_${langSuffix}.txt`, buildTxt(entries));
                  } else if (format === 'srt') {
                    zip.file(`${safeTitle}_${langSuffix}.srt`, buildSrt(entries));
                  } else if (format === 'md') {
                    zip.file(`${safeTitle}_${langSuffix}.md`, buildMd(title, author, videoUrl, langLabel, entries));
                  }
                }
              } catch (err) {
                console.error(`Failed to fetch batch transcript ${l.code} for ${videoId}:`, err.message);
              }
            }
            if (successLangs.length > 0) {
              logEntries[idx] = {
                videoId,
                title,
                status: 'SUCCESS',
                sourceLang: successLangs.join(', '),
                details: `All available languages in format: ${format.toUpperCase()}`
              };
              playlistMetadata[idx] = {
                videoId,
                title,
                channel: author,
                videoUrl,
                thumbnail: thumbnailUrl,
                status: 'SUCCESS'
              };
            } else {
              throw new Error('No transcripts available for any language.');
            }
          }
          return;
        }

        // Fetch transcript entries
        let entries = await fetchTranscriptEntries(videoId, lang);
        if (!entries || entries.length === 0) throw new Error('No transcripts found for this video.');

        if (effectiveTarget !== 'original') {
          entries = await translateText(entries, effectiveTarget);
        }

        const langSuffix = effectiveTarget === 'original' ? 'orig' : effectiveTarget;
        const langLabel = effectiveTarget === 'original' ? 'Original (no translation)' : effectiveTarget.toUpperCase();

        if (format === 'txt') {
          const txtContent = buildTxt(entries);
          zip.file(`${safeTitle}_${langSuffix}.txt`, txtContent);
        } else if (format === 'srt') {
          const srtContent = buildSrt(entries);
          zip.file(`${safeTitle}_${langSuffix}.srt`, srtContent);
        } else if (format === 'md') {
          const mdContent = buildMd(title, author, videoUrl, langLabel, entries);
          zip.file(`${safeTitle}_${langSuffix}.md`, mdContent);
        } else if (format === 'zip') {
          // Build txt, srt, md, docx, pdf
          const [txtContent, srtContent, mdContent, docxBuffer, pdfBuffer] = await Promise.all([
            Promise.resolve(buildTxt(entries)),
            Promise.resolve(buildSrt(entries)),
            Promise.resolve(buildMd(title, author, videoUrl, langLabel, entries)),
            buildDocx(title, author, videoUrl, langLabel, entries),
            buildPdf(title, author, videoUrl, langLabel, entries),
          ]);

          const metadata = {
            videoId,
            title,
            channel: author,
            channelIcon: authorIcon,
            videoUrl,
            thumbnail: thumbnailUrl,
            transcriptLanguage: langLabel,
            captionCount: entries.length,
            generatedAt: new Date().toISOString()
          };

          const subFolder = zip.folder(safeTitle);
          subFolder.file(`${safeTitle}_${langSuffix}.txt`,  txtContent);
          subFolder.file(`${safeTitle}_${langSuffix}.srt`,  srtContent);
          subFolder.file(`${safeTitle}_${langSuffix}.md`,   mdContent);
          subFolder.file(`${safeTitle}_${langSuffix}.docx`, docxBuffer);
          subFolder.file(`${safeTitle}_${langSuffix}.pdf`,  pdfBuffer);
          subFolder.file('metadata.json', JSON.stringify(metadata, null, 2));
          if (thumbnailBuffer) subFolder.file('thumbnail.jpg', thumbnailBuffer);
          // Include user's screenshot if this video was found via screenshot upload
          const batchShot = consumeScreenshot(videoId);
          if (batchShot) subFolder.file(`input_screenshot${batchShot.ext}`, batchShot.buf);
        }

        logEntries[idx] = {
          videoId,
          title,
          status: 'SUCCESS',
          sourceLang: langLabel,
          details: format === 'zip' ? 'All formats single ZIP' : `Format: ${format.toUpperCase()}`
        };
        playlistMetadata[idx] = {
          videoId,
          title,
          channel: author,
          videoUrl,
          thumbnail: thumbnailUrl,
          status: 'SUCCESS'
        };
      } catch (itemErr) {
        console.error(`Error processing video ${videoId} in batch:`, itemErr.message);
        logEntries[idx] = {
          videoId,
          status: 'FAILED',
          error: itemErr.message
        };
        playlistMetadata[idx] = {
          videoId,
          status: 'FAILED',
          error: itemErr.message
        };
      }
    });

    await Promise.all(fetchPromises);

    // Save download summary logs
    const logsContent = buildLogsText(logEntries, playlistTitle || 'Batch Export', isPlaylist, targetLang);
    zip.file('download_summary_logs.txt', logsContent);

    // Save metadata json file
    const masterMetadata = {
      title: playlistTitle || 'Batch Export',
      type: isPlaylist ? 'playlist' : 'batch',
      exportedAt: new Date().toISOString(),
      targetLanguage: targetLang,
      format,
      totalVideos: items.length,
      successCount: logEntries.filter(e => e && e.status === 'SUCCESS').length,
      failedCount: logEntries.filter(e => e && e.status === 'FAILED').length,
      videos: playlistMetadata.filter(Boolean)
    };
    zip.file('playlist_metadata.json', JSON.stringify(masterMetadata, null, 2));

    const zipBuffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 6 } });
    
    const safeTitleName = (playlistTitle || 'Batch_Export').replace(/[^a-zA-Z0-9 _\-]/g, '').replace(/\s+/g, '_').substring(0, 50);
    const langLabelName = effectiveTarget === 'original' ? 'Original' : (effectiveTarget === 'all' ? 'All_Languages' : effectiveTarget.toUpperCase());
    const formatLabelName = format === 'zip' ? 'All_Formats_Master' : format.toUpperCase();
    const zipFilename = isPlaylist 
      ? `Playlist_${safeTitleName}_${langLabelName}_${formatLabelName}.zip` 
      : `Batch_${langLabelName}_${formatLabelName}.zip`;

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${zipFilename}"`);
    res.send(zipBuffer);
  } catch (err) {
    console.error('Batch ZIP download error:', err);
    res.status(500).json({ error: 'Failed to create batch ZIP: ' + err.message });
  }
});

// ── OCR text cleaner ─────────────────────────────────────────────────────────
// Returns { primary, secondary } where:
//   primary  = mixed-case lines (video title / channel name area below thumbnail)
//   secondary = all-caps lines (thumbnail artwork text — large bold text on image)
// We search with primary first; fall back to secondary if primary fails.
function cleanOcrTextToQuery(rawText) {
  if (!rawText) return { primary: '', secondary: '' };

  // Noise removal — keep apostrophes, quotes, dots for better search relevance
  const noise = (line) => line
    .replace(/\b\d{1,2}:\d{2}(:\d{2})?\b/gi, '')     // timestamps (34:22)
    .replace(/\b\d[\.\d]*[kKmM]?\s+views?\b/gi, '')   // view counts
    .replace(/\b\d+\s+(day|week|month|year|hour|min)s?\s+ago\b/gi, '') // dates
    .replace(/[|•·◦►▸▶⟩»©®™°…]+/g, ' ')               // icons/bullets
    .replace(/[^\w\s'"\-:.!?,&]/g, ' ')                // keep apostrophes, quotes
    .replace(/\s+/g, ' ').trim();

  const lines = rawText.split(/[\r\n]+/);
  const allCapsLines   = []; // likely thumbnail artwork ("SOFTWARE IS THE NEW YOUTUBE")
  const mixedCaseLines = []; // likely title/channel metadata ("The YouTubification of...")

  for (const line of lines) {
    const cleaned = noise(line);
    if (cleaned.length < 3) continue;
    // Skip pure-number / symbol lines
    if (/^[\d\s\-_.:,;+*&%$#@!^()'"]+$/.test(cleaned)) continue;
    // Categorise: does it contain ANY lowercase letter?
    if (/[a-z]/.test(cleaned)) {
      mixedCaseLines.push(cleaned);
    } else {
      allCapsLines.push(cleaned);
    }
  }

  mixedCaseLines.sort((a, b) => b.length - a.length);
  allCapsLines.sort((a, b) => b.length - a.length);

  // Primary query: mixed-case lines + shortest all-caps word (often a channel watermark like "SMHZ")
  const mixedQuery = mixedCaseLines.slice(0, 2).join(' ').trim();
  const watermark   = allCapsLines.find(l => l.split(/\s+/).length <= 2) || '';
  const primary     = (mixedQuery + (watermark ? ' ' + watermark : '')).trim();

  // Secondary query: all-caps thumbnail art text (fallback)
  const secondary   = allCapsLines.slice(0, 2).join(' ').trim();

  return { primary, secondary };
}

// ── Screenshot OCR check ──────────────────────────────────────────────────────
// Score a search result video against raw OCR text
function scoreVideoAgainstOcr(video, ocrText) {
  const textLower = ocrText.toLowerCase();
  let score = 0;

  // Channel name in OCR? (+20)
  const author = (video.channelTitle || '').toLowerCase();
  if (author && textLower.includes(author)) score += 20;

  // Duration visible in OCR? (+50 - Massive bonus for exact timestamp match)
  const dur = video.length?.simpleText || '';
  if (dur && textLower.includes(dur)) score += 50;

  // Title word-overlap with OCR text (+0..10)
  const title = video.translatedTitle || video.title || '';
  if (title) {
    const titleWords = title.toLowerCase().split(/\s+/).filter(w => w.length > 3);
    let matched = 0;
    for (const w of titleWords) { if (textLower.includes(w)) matched++; }
    if (titleWords.length > 0) score += (matched / titleWords.length) * 10;
  }

  // Bonus: any individual title word >=5 chars found verbatim in OCR (+2 per word, max 6)
  const titleWords5 = (title).toLowerCase().split(/\s+/).filter(w => w.length >= 5);
  let bonus = 0;
  for (const w of titleWords5) { if (textLower.includes(w)) bonus += 2; if (bonus >= 6) break; }
  score += bonus;

  return score;
}

app.post('/api/check-screenshot', upload.single('screenshot'), async (req, res) => {

  // If no uploaded file, check if a local filePath was provided
  if (!req.file && req.body.filePath && fs.existsSync(req.body.filePath)) {
    const os = require('os');
    const originalname = path.basename(req.body.filePath);
    const tempPath = path.join(os.tmpdir(), `temp_ocr_${Date.now()}_${originalname}`);
    fs.copyFileSync(req.body.filePath, tempPath);
    req.file = {
      path: tempPath,
      originalname: originalname
    };
  }

  if (!req.file) return res.json({ valid: false, error: 'No image file received.' });
  const filePath = req.file.path;
  const fileExt  = path.extname(req.file.originalname).toLowerCase() || '.jpg';
  const cleanup  = () => { try { fs.unlinkSync(filePath); } catch {} };

  try {
    const { data: { text } } = await Tesseract.recognize(filePath, 'eng', {
      logger: () => {},
      tessedit_pageseg_mode: '6',   // assume a uniform block of text
    });
    // NOTE: do NOT delete filePath here — we may cache it for ZIP inclusion
    if (!text || text.trim().length === 0) {
      cleanup();
      return res.json({ valid: false, error: 'Could not extract any text from the image.' });
    }

    let videoId = null;
    let videoInfo = null;
    let extractedUrl = null;
    let autoConfirmed = false;

    // ── Step 1: URL in screenshot? → instant match ─────────────────────────
    const found = extractYouTubeFromText(text);
    if (found) {
      videoId = found.videoId;
      extractedUrl = found.url;
    } else {
      // ── Step 2: Build multiple search queries from OCR text ───────────────
      const { primary, secondary } = cleanOcrTextToQuery(text);
      // Also try a raw-word fallback: significant words (≥5 chars) from all OCR text
      const rawWords = text
        .replace(/[^\w\s']/g, ' ')
        .split(/\s+/)
        .filter(w => w.length >= 5)
        .slice(0, 8)
        .join(' ');

      // De-duplicate and filter empty
      const queries = [...new Set([primary, secondary, rawWords])].filter(q => q.length > 4);
      console.log('OCR queries to try:', queries);

      const YTSearch = require('youtube-search-api');
      let bestVideo = null;
      let highestScore = 0;

      for (const q of queries) {
        try {
          // Increased search depth to 20 to ensure we find the full video, not just the summary
          const results = await YTSearch.GetListByKeyword(q, false, 20);
          const videos = (results?.items || []).filter(i => i.type === 'video' || !i.type);
          
          // Batch translate all video titles to English to match English OCR text
          if (videos.length > 0) {
            const titles = videos.map(v => v.title || 'Untitled');
            const combinedTitles = titles.join(' |||SPLIT||| ');
            try {
              const { translate } = require('@vitalets/google-translate-api');
              const res = await translate(combinedTitles, { to: 'en' });
              const translatedTitles = res.text.split('|||SPLIT|||').map(t => t.trim());
              for (let i = 0; i < videos.length; i++) {
                videos[i].translatedTitle = translatedTitles[i] || titles[i];
              }
            } catch (err) {
              console.error('Title translation failed for OCR matching:', err.message);
            }
          }

          for (const video of videos) {
            const score = scoreVideoAgainstOcr(video, text);
            if (score > highestScore) { highestScore = score; bestVideo = video; }
          }
        } catch (searchErr) {
          console.error('OCR search error for query "' + q + '":', searchErr.message);
        }
      }

      // Accept any result with score >= 1 (show confirmation dialog)
      // Auto-confirm only at score >= 8
      if (bestVideo && highestScore >= 1) {
        videoId = bestVideo.id;
        videoInfo = {
          title: bestVideo.title,
          author: bestVideo.channelTitle || '',
          authorIcon: '',
          duration: bestVideo.length?.simpleText || '',
          thumbnail: `https://img.youtube.com/vi/${bestVideo.id}/hqdefault.jpg`
        };
        if (highestScore >= 8) autoConfirmed = true;
      }
    }

    if (!videoId) {
      cleanup();
      return res.json({
        valid: false,
        error: 'Could not identify any matching YouTube video from the screenshot.',
        extractedText: text.substring(0, 500)
      });
    }

    const history = getHistory();
    if (!videoInfo) videoInfo = history[videoId] || await fetchVideoInfo(videoId);

    if (videoInfo) {
      const textLower = text.toLowerCase();
      const authorMatch = videoInfo.author && textLower.includes(videoInfo.author.toLowerCase());
      const titleMatch = videoInfo.title && textLower.includes(videoInfo.title.toLowerCase());
      const durationMatch = videoInfo.duration && textLower.includes(videoInfo.duration);
      const isConfirmed = req.body.confirmed === 'true';
      const hasStrongMatch = autoConfirmed || titleMatch || (authorMatch && durationMatch);
      if (!isConfirmed && !hasStrongMatch) {
        // Keep file for potential later use after confirmation
        cacheScreenshot(videoId, filePath, fileExt);
        return res.json({ valid: true, requireConfirmation: true, videoId, videoInfo, extractedText: text.substring(0, 500) });
      }
    }

    // Cache screenshot so it can be included in ZIP downloads
    cacheScreenshot(videoId, filePath, fileExt);

    const result = await runTranscriptCheck(videoId);
    return res.json({ ...result, extractedUrl: extractedUrl || `https://www.youtube.com/watch?v=${videoId}`, extractedText: text.substring(0, 500), hasInputScreenshot: true });
  } catch (err) {
    cleanup();
    console.error('Screenshot OCR error:', err);
    return res.json({ valid: false, error: 'Failed to process image: ' + err.message });
  }
});

// ── Start ─────────────────────────────────────────────────────────────────────
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`YouTube Checker running at http://localhost:${PORT}`);
    const { exec } = require('child_process');
    const startCmd = process.platform === 'win32' ? 'start' : process.platform === 'darwin' ? 'open' : 'xdg-open';
    exec(`${startCmd} http://localhost:${PORT}`);
  });
}

module.exports = app;
